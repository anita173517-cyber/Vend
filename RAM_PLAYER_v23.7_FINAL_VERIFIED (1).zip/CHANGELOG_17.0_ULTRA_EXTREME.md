# StreamX Media3 Pro v17.0 — Ultra Extreme Edition

## Base and preservation

- Built from the supplied v16.0 Ultra Max Edition source tree; v15.0 was also inspected for project lineage and feature preservation.
- Preserves the 4D Glass TV UI, existing view/resource IDs, remote navigation, Media3 1.11.1 playback stack, HLS preloading, playlist parsing, SXB2 cache, XMLTV EPG, Xtream live/VOD flow, encrypted profiles, parental PIN, boot receiver, and low-memory policies.

## Fixes and improvements

1. **Xtream duplicate-channel fallback:** duplicate normalized channel entries now select the alternate stream ID's `.ts` URL as backup. This keeps the documented primary-HLS / alternate-TS strategy consistent.
2. **Xtream VOD resilience:** VOD loading now shares the repository mutex with live loading and uses at most two attempts for transient network/server failures, with a short bounded delay. Cancellation remains cooperative and active HTTP calls are tracked for cancellation.
3. **VOD URL safety:** provider-supplied container extensions are restricted to a short alphanumeric extension before URL construction.
4. **Release identity:** version code/name are now 170 / 17.0. GitHub Actions output and artifact names now identify v17.0.
5. **Verification:** structural verifier now checks the corrected TS fallback, bounded VOD retry, and extension sanitization.

## Performance and compatibility notes

- Existing 65ms focus-prefetch debounce, 180ms adjacent preload delay, 320KB bounded preload cache, 96KB segment prefix, async MediaCodec queueing, and CLOSEST_SYNC seek configuration are preserved from v16.0.
- These values are configuration/source facts, not measured channel-zap or playlist-load timings.
- Android minimum remains API 23 (Android 6.0); Media3 remains 1.11.1; target SDK remains 34; compile SDK remains 36.
- No new player instance, unbounded cache, or speculative top-eight stream warmup is introduced.

## Verification status

- Offline XML/resource/source verifier: run separately and recorded in `BUILD_VERIFICATION_17.0.txt`.
- Android Gradle unit tests and release APK build: configured in `.github/workflows/build_apk.yml`; must complete successfully in GitHub Actions.
- Physical TV/network playback and measured performance benchmarks: not run in this environment.
