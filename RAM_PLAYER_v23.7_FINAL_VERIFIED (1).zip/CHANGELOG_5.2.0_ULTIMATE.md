# StreamX Media3 Pro 5.2.0 Ultimate

## Preserved
- Existing dark-glass/cyan interface, screen layout, channel navigation and remote-control behavior.
- Existing M3U/Xtream profiles, encrypted credential storage, EPG, favorites, recents, search, categories, sleep timer, aspect ratio and playback recovery.
- Premium DTH startup animation and first-rendered-frame overlay behavior from 5.1.0.

## Engine and reliability updates
- Updated all AndroidX Media3 modules together from 1.4.1 to stable 1.11.1.
- Updated Android Gradle Plugin/Kotlin toolchain and compile SDK for the current Media3 toolchain.
- Set minSdk to 23 (Android 6.0) to align with the current AndroidX baseline; Android 5.x devices are no longer in the supported range for this build.
- Split metadata, playlist/EPG and live-stream HTTP dispatchers and connection pools so background requests cannot exhaust live playback request slots.
- Increased live segment read timeout from 10s to 20s to reduce false failures during brief Wi-Fi jitter; this is not a way to fix an unavailable provider or underpowered network.
- Kept network concurrency bounded for low-memory TV boxes.
- Disabled unnecessary backward sample retention for live TV to reduce memory pressure.
- Enabled standard media audio attributes and pause-on-audio-output-disconnect behavior.
- Added JVM unit tests for M3U metadata parsing, BOM handling, duplicate URL removal and channel limits.
- Updated CI to run unit tests, debug/release APK builds and upload artifacts.

## Validation status
- Static project/XML/config checks: run locally when packaging.
- Unit tests and Android APK compilation: configured in GitHub Actions; not executed in this offline workspace.
- Real-device playback, startup black-flash, channel-zap latency, low-RAM behavior and provider-specific stream compatibility: require Android TV hardware and authorized test streams.

No version can guarantee zero buffering. Playback depends on provider origin, stream encoding, CDN, Wi-Fi/Ethernet, device decoder and TV firmware.
