package com.harindra.iptvpro

import com.harindra.iptvpro.vod.VodErrorCategory
import com.harindra.iptvpro.vod.VodPlaybackErrorHandler
import com.harindra.iptvpro.vod.VodPreferencesStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Live TV Regression & VOD Isolation Tests.
 * Verifies that upgrading VOD does not alter Live TV playback state, channel switching,
 * Xtream live URL construction, or Live TV preferences.
 */
class LiveTvVodIsolationRegressionTest {

    @Test
    fun liveTvStateSurvivesVodEntryAndExit() {
        LiveTvBackgroundPlaybackController.clearSuspendedState()
        val suspended = LiveTvBackgroundPlaybackController.recordLiveTvSuspended(
            channelIndex = 42,
            channelId = "live_ch_42",
            channelName = "Star Sports 1 HD",
            targetSectionName = "Movies",
            nowMs = 55_000L
        )
        assertTrue(suspended.wasSuspended)
        assertEquals(42, suspended.channelIndex)
        assertEquals("live_ch_42", suspended.channelId)
        assertEquals("Star Sports 1 HD", suspended.channelName)

        // Simulate a VOD playback error occurring while Live TV is suspended
        val vodErrorHandler = VodPlaybackErrorHandler()
        val vodErr = vodErrorHandler.classifyHttpStatus(404)
        assertEquals(VodErrorCategory.NOT_FOUND, vodErr.category)

        // Live TV suspended state must remain completely intact and unaffected by VOD errors
        val peeked = LiveTvBackgroundPlaybackController.peekSuspendedState()
        assertTrue(peeked.wasSuspended)
        assertEquals("live_ch_42", peeked.channelId)

        // Returning to Live TV restores the exact channel once
        val restored = LiveTvBackgroundPlaybackController.consumeSuspendedState()
        assertEquals(42, restored.channelIndex)
        assertEquals("live_ch_42", restored.channelId)
        assertFalse(LiveTvBackgroundPlaybackController.peekSuspendedState().wasSuspended)
    }

    @Test
    fun vodPreferencesFileIsStrictlyIsolatedFromLiveTvProfileStore() {
        assertNotEquals("streamx_profiles_v1", VodPreferencesStore.PREFS_FILE_NAME)
        assertEquals("ram_player_vod_prefs_v21", VodPreferencesStore.PREFS_FILE_NAME)
    }

    @Test
    fun xtreamLiveStreamUrlsRemainUnchangedAfterVodUpgrade() {
        val repo = XtreamRepository()
        val (primary, backup) = repo.buildLiveStreamUrls(
            cleanBase = "http://demo.provider.test:8080",
            username = "u1",
            password = "p1",
            streamId = "999",
            allowedOutputFormats = listOf("m3u8", "ts"),
            preferredExtension = "auto"
        )
        assertEquals("http://demo.provider.test:8080/live/u1/p1/999.m3u8", primary)
        assertEquals("http://demo.provider.test:8080/live/u1/p1/999.ts", backup)
    }
}
