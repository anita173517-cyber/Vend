package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v23.7 — Hardened Recovery State Machine, Watchdog Exhaustion,
 * Exactly-Once Counting & Backup URL Idempotency Unit Tests.
 */
class PlaybackRecoveryV237Test {

    @Test
    fun evaluateDecisionIsPureReadOnlyAndDoesNotIncrementCounters() {
        val session = BoundedRecoverySession(sessionToken = 201L, channelKey = "ch_pure")
        val err503 = SmartChannelIntelligenceEngine.classifyPlaybackError(
            httpStatusCode = 503,
            errorCodeName = "ERROR_CODE_IO_BAD_HTTP_STATUS",
            message = "Service Unavailable",
            engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
        )
        // Checking multiple times without committing must leave counters at 0
        session.evaluateDecision(err503, hasBackupUrl = false)
        session.evaluateDecision(err503, hasBackupUrl = false)
        assertEquals(0, session.retryCount)
        assertEquals(0, session.totalRecoveryAttempts)
    }

    @Test
    fun duplicateActionIdsAndRepeatedBackupUrlCallsNeverDoubleCount() {
        val session = BoundedRecoverySession(sessionToken = 202L, channelKey = "sony_max_hd")
        val backup = "http://xtream.example:8080/live/u/p/343.ts"

        // Commit engine switch once with same actionId twice -> count must stay 1
        assertTrue(session.commitRecoveryAction("switch_1", CommittedRecoveryType.ENGINE_SWITCH))
        assertFalse(session.commitRecoveryAction("switch_1", CommittedRecoveryType.ENGINE_SWITCH))
        assertEquals(1, session.engineSwitchCount)
        assertEquals(1, session.totalRecoveryAttempts)

        // Repeated backup URL calls (with whitespace/duplicates) -> count increments only once
        assertTrue(session.markBackupUrlTried(backup))
        assertFalse(session.markBackupUrlTried("  $backup  "))
        assertFalse(session.markBackupUrlTried(""))
        assertFalse(session.markBackupUrlTried("not-a-valid-url"))
        assertEquals(2, session.totalRecoveryAttempts)
        assertTrue(session.backupUrlTried)
        assertTrue(session.hasAttemptedUrl(backup))
    }

    @Test
    fun watchdogBudgetIsStrictlyBoundedAndStopsAfterExhaustion() {
        val session = BoundedRecoverySession(sessionToken = 203L, channelKey = "zee_cinema")
        session.transitionTo(RecoveryLifecycleState.PRIMARY_STARTED)

        assertTrue(session.canTriggerWatchdog(nowElapsedMs = 5000L))
        assertTrue(
            session.commitRecoveryAction(
                actionId = "watchdog_1",
                type = CommittedRecoveryType.WATCHDOG_HEAL,
                nowElapsedMs = 5000L,
                minCooldownMs = 2000L
            )
        )
        // Duplicate watchdog immediately or after cooldown must be blocked (MAX_WATCHDOG_INTERVENTIONS = 1)
        assertFalse(session.canTriggerWatchdog(nowElapsedMs = 5500L))
        assertFalse(session.canTriggerWatchdog(nowElapsedMs = 20000L))
        assertEquals(1, session.watchdogInterventions)

        // Marking exhausted prevents any further automatic recovery
        session.markExhausted()
        assertTrue(session.isExhausted())
        assertFalse(session.commitRecoveryAction("retry_after_exhaust", CommittedRecoveryType.RETRY))
    }

    @Test
    fun media3OnlyModeStopsCleanlyAfterBackupWithoutInfiniteRestart() {
        val session = BoundedRecoverySession(sessionToken = 204L, channelKey = "star_gold")
        val primary = "http://xtream.example:8080/live/u/p/500.m3u8"
        val backup = "http://xtream.example:8080/live/u/p/500.ts"
        session.markUrlAttempted(primary)

        val codecErr = SmartChannelIntelligenceEngine.classifyPlaybackError(
            httpStatusCode = 0,
            errorCodeName = "ERROR_CODE_DECODER_INIT_FAILED",
            message = "MediaCodec failed",
            engineMode = LiveTvEngineMode.MEDIA3_ONLY
        )
        assertEquals(ErrorRecoveryAction.NONE_STOP, codecErr.action)
        assertEquals(ChannelPlaybackResult.UNSUPPORTED, codecErr.result)

        val nextStage = LiveTvEngineRouter.nextHealStage(
            current = LiveTvHealStage.EXO_PRIMARY,
            hasBackupUrl = true,
            engineMode = LiveTvEngineMode.MEDIA3_ONLY
        )
        assertEquals(LiveTvHealStage.EXO_BACKUP_FORMAT, nextStage)
        assertTrue(session.markBackupUrlTried(backup))
        // After EXO_BACKUP_FORMAT, nextHealStage MUST be null (stops cleanly!)
        assertEquals(
            null,
            LiveTvEngineRouter.nextHealStage(
                current = LiveTvHealStage.EXO_BACKUP_FORMAT,
                hasBackupUrl = true,
                engineMode = LiveTvEngineMode.MEDIA3_ONLY
            )
        )
    }

    @Test
    fun stateMachineRejectsIllegalTransitionsAndCancelledSessionBlocksMutations() {
        val session = BoundedRecoverySession(sessionToken = 205L, channelKey = "ch_cancel")
        assertTrue(session.transitionTo(RecoveryLifecycleState.PRIMARY_STARTED))
        session.markPlaybackConfirmed()
        assertEquals(RecoveryLifecycleState.PLAYBACK_CONFIRMED, session.state)
        // Confirmed playback must NOT trigger watchdog
        assertFalse(session.canTriggerWatchdog(nowElapsedMs = 10000L))

        // Cancel session (simulates user zapping to another channel)
        session.cancelSession()
        assertTrue(session.isCancelled())
        // Stale callbacks cannot mutate a cancelled session
        assertFalse(session.transitionTo(RecoveryLifecycleState.RECOVERY_COMMITTED))
        assertFalse(session.markBackupUrlTried("http://xtream.example:8080/live/u/p/999.ts"))
        assertFalse(session.commitRecoveryAction("stale_retry", CommittedRecoveryType.RETRY))
    }

    @Test
    fun cooldownPreventsSimultaneousDuplicateRecoveryCommits() {
        val session = BoundedRecoverySession(sessionToken = 206L, channelKey = "ch_cool")
        assertTrue(
            session.commitRecoveryAction(
                actionId = "retry_1",
                type = CommittedRecoveryType.RETRY,
                nowElapsedMs = 10_000L,
                minCooldownMs = 2000L
            )
        )
        // Simultaneous callback 200ms later must be rejected by cooldown
        assertFalse(
            session.commitRecoveryAction(
                actionId = "retry_2",
                type = CommittedRecoveryType.RETRY,
                nowElapsedMs = 10_200L,
                minCooldownMs = 2000L
            )
        )
        // After 2500ms cooldown passes, commit succeeds
        assertTrue(
            session.commitRecoveryAction(
                actionId = "retry_2",
                type = CommittedRecoveryType.RETRY,
                nowElapsedMs = 12_500L,
                minCooldownMs = 2000L
            )
        )
        assertEquals(2, session.totalRecoveryAttempts)
    }
}
