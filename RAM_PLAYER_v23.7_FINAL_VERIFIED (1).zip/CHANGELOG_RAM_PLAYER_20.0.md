# RAM PLAYER v20.0 — Final Ultimate Edition (Build 200)

## What's New in v20.0
- **Dual Device Optimization Modes (`Models.kt` + `ProfileStore.kt`)**: Preserves `512MB Low-RAM Mode` (`LOW_MEMORY` / `AUTO_ADAPTIVE`) as safe default and adds `4GB High-Performance Mode` (`HIGH_PERFORMANCE_4GB`) with bounded `DeviceOptimizationProfile` cache/prefetch limits, manual selection lock, and automatic memory-pressure fallback.
- **Dedicated Media3 `MediaSessionService` (`RamPlayerPlaybackService.kt`)**: Single authoritative MediaSession attached to `ExoPlayer` with `media3-session:1.11.1`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, and clean lifecycle registration/unregistration.
- **Independent Per-Profile & Per-Playlist WorkManager Schedules (`PlaylistRefreshWorker.kt`)**: Unique work names (`ram_player_refresh_<profileId>_<playlistId>`), explicit `profile_id` / `playlist_id` Worker input, automatic cancellation on deletion/disable, and exponential backoff retry.
- **Genuine Recycle Bin (`RecycleBinEntry`, `ProfileStore.kt`, `PlayerActivity.kt`)**: Soft-delete for deleted profiles & custom channel groups (separate from Hide/Unhide and Channel Blacklist), 30-day retention, Restore Individual / Restore All, Permanent Delete, and Empty Bin with confirmation.
- **Transactional Restore with Automatic Rollback (`SmartEngineHub.kt`)**: Snapshots existing user state prior to staging/committing `SXBK_V20`/`SXBK_V19` restores and rolls back atomically if any error occurs.
- **Network Security Config (`res/xml/network_security_config.xml`)**: Documented explicit HTTP IPTV compatibility alongside system trust anchors.
- **Expanded Unit Tests (`M3uParserTest.kt`)**: Added tests for 512MB vs 4GB `DeviceOptimizationProfile`, memory-pressure fallback, `RecycleBinEntry` expiry, and independent WorkManager unique work naming.
